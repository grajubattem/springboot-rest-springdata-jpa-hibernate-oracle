INSERT INTO 
	TBL_SALESORDERS (customer_name, no_of_items) 
VALUES
  	('Sanjay', 100),
  	('Raju', 90);